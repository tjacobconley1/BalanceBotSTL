
import numpy as np