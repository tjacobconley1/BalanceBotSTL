package balbotstl;

public class main {

	public main() {
		// TODO Auto-generated constructor stub
	
		System.out.println("BALANCE BOT STL");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
