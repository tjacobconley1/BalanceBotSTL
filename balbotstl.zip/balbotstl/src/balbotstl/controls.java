package balbotstl;

public interface controls {

}
